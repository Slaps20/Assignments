def main():
    return(print("Hello World"))

main()